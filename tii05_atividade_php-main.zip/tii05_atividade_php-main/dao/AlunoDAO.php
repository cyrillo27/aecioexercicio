<?php

require_once 'BaseDAO.php';
require_once '/entities/Aluno.php';
require_once '/entities/Disciplina.php';

class AlunoDAO implements BaseDAO {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getById($id) {
        $sql = "SELECT * FROM aluno WHERE matricula = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return new Aluno($row['matricula'], $row['nome']);
    }

    public function getAll() {
        $sql = "SELECT * FROM aluno";
        $stmt = $this->db->query($sql);
        $alunos = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $alunos[] = new Aluno($row['matricula'], $row['nome']);
        }
        return $alunos;
    }

    public function create($entity) {
        
    }

    public function update($entity) {
        
    }

    public function delete($id) {
        
    }

    public function getAlunoWithDisciplinas($alunoID) {
        $sql = "SELECT d.id, d.nome, d.carga_horaria
                FROM aluno a
                JOIN disciplina_aluno da ON a.matricula = da.aluno_id
                JOIN disciplina d ON da.disciplina_id = d.id
                WHERE a.matricula = :alunoID";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':alunoID', $alunoID);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $aluno = new Aluno($row['matricula'], $row['nome']);
        $disciplinas = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $disciplinas[] = new Disciplina($row['id'], $row['nome'], $row['carga_horaria']);
        }

        $aluno->setDisciplinas($disciplinas);

        return $aluno;
    }
}
?>
