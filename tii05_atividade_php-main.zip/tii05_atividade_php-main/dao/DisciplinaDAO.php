<?php
// /dao/DisciplinaDAO.php
require_once 'BaseDAO.php';
require_once '/entities/Disciplina.php';
require_once '/entities/Aluno.php';

class DisciplinaDAO implements BaseDAO {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getById($id) {
        $sql = "SELECT * FROM disciplina WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return new Disciplina($row['id'], $row['nome'], $row['carga_horaria']);
    }

    public function getAll() {
        $sql = "SELECT * FROM disciplina";
        $stmt = $this->db->query($sql);
        $disciplinas = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $disciplinas[] = new Disciplina($row['id'], $row['nome'], $row['carga_horaria']);
        }
        return $disciplinas;
    }

    public function create($entity) {
        
    }

    public function update($entity) {
        
    }

    public function delete($id) {
        
    

    public function getDisciplinaWithAlunos($disciplinaID) {
        $sql = "SELECT a.matricula, a.nome
                FROM disciplina d
                JOIN disciplina_aluno da ON d.id = da.disciplina_id
                JOIN aluno a ON da.aluno_id = a.matricula
                WHERE d.id = :disciplinaID";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':disciplinaID', $disciplinaID);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $disciplina = new Disciplina($row['id'], $row['nome'], $row['carga_horaria']);
        $alunos = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $alunos[] = new Aluno($row['matricula'], $row['nome']);
        }

        $disciplina->setAlunos($alunos);

        return $disciplina;
    }
}
?>
